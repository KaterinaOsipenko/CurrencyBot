CurrencyBot
Telegram Bot for conversion currency

You can find bot on Telegram by nickname @CurrCurrencyBot or https://t.me/CurrCurrencyBot.

Monobank API is used for retrieving actual data for currency bot.

Information updates every 5 minutes as API. 

Default initial currency is UAN and default target currency is USD.

Conversion from one foreign currency to another takes place through transit conversion into the national currency.

