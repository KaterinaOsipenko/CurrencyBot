package com.spring.currency.bot.model;

public enum CallbackTitle {

  INITIAL,

  TARGET,

  RATE,

  CONVERSION,

  CALCULATE
}
